import { Component } from '@angular/core';

@Component({
  selector: 'app-multiplication',
  templateUrl: './multiplication.component.html',
  styleUrls: ['./multiplication.component.css']
})
export class MultiplicationComponent {

  res:number=0

  fun(inpelement1:any,inpelement2:any){
    // console.log(inpelement1.value,inpelement2.value)
    this.res=parseInt(inpelement1.value)*parseInt(inpelement2.value)
  }

}
