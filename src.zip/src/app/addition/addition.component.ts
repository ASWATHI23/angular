import { Component } from '@angular/core';

@Component({
  selector: 'app-addition',
  templateUrl: './addition.component.html',
  styleUrls: ['./addition.component.css']
})
export class AdditionComponent {

  res:number=0

  fun(inpelement1:any,inpelement2:any){
    // console.log(inpelement1.value,inpelement2.value)
    this.res=parseInt(inpelement1.value)+parseInt(inpelement2.value)
  }

}
