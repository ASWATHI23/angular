import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {FirstComponent} from './first/first.component'
import {HomeComponent} from './home/home.component'
import {SecondComponent} from './second/second.component'
import { AdditionComponent } from './addition/addition.component'
import { MultiplicationComponent } from './multiplication/multiplication.component'
import { LoginComponent } from './login/login.component'

const routes: Routes = [
  {path:'fst',component:FirstComponent},
  {path:'snd',component:SecondComponent},
  {path:'add',component:AdditionComponent},
  {path:'mul',component:MultiplicationComponent},
  {path:'log',component:LoginComponent},
  {path:'',component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
