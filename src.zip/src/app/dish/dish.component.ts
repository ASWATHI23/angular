import { Component } from '@angular/core';
import { OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-dish',
  templateUrl: './dish.component.html',
  styleUrls: ['./dish.component.css']
})
export class DishComponent implements OnInit {

  pid:any=""
  dish:any=""
  reviews:any=[]

  constructor(private ar:ActivatedRoute,private ds:DataService){
    ar.params.subscribe(data=>this.pid=data['id'])
  }

  ngOnInit(): void {

    this.ds.getSpecDish(this.pid).then(r=>r.json()).then(data=>this.getdata(data));
    this.ds.getReviews(this.pid).then(r=>r.json()).then(data=>this.getdata1(data))
    
  }

  getdata(d:any){
    this.dish=d
    console.log(this.dish)

  }
  getdata1(d:any){
    this.reviews=d
    console.log(this.reviews)
  }

}
