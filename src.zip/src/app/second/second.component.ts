import { Component } from '@angular/core';

@Component({
  selector: 'app-second',
  templateUrl: './second.component.html',
  styleUrls: ['./second.component.css']
})
export class SecondComponent {

  // data:any=[
  //   {id:1,name:"ammu",age:15,class:"10A"},
  //   {id:2,name:"akkuu",age:15,class:"10B"},
  //   {id:3,name:"achu",age:15,class:"10A"},
  //   {id:4,name:"anju",age:15,class:"10C"}
  // ]
  data:any=null
}
