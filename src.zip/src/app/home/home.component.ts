import { Component } from '@angular/core';
import {Router} from '@angular/router';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  date:any="2001-02-27"
  data:any=""

  constructor(private r:Router,private ds:DataService){
    ds.getData().then(r=>r.json()).then(data=>this.data=data)
    // this.data=ds.getData()

  }

  getProduct(e:any){
    let id =e.target.id
    this.r.navigate(["det",id])

  }

}
