import { Component } from '@angular/core';
import { FormBuilder,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  un:string="username"
  ps:string="password"

  logform=this.fb.group({
    username:['',[Validators.required,Validators.pattern("[a-zA-Z0-9]+")]],
    password:['',[Validators.required,Validators.minLength(2)]]
  })

  constructor(private fb:FormBuilder,private r:Router,private ds:DataService){

  }

  log(){
    if(this.logform.valid){
      console.log(this.logform.value)
      // let token:any=""
      this.ds.getToken(this.logform.value).then(r=>r.json()).then(data=>{
        if (data["token"]){
          localStorage.setItem("token",data["token"])
        }
        else{
          localStorage.setItem("token","null")
        }
      })
        // localStorage.setItem("token",data["token"]))
      if (localStorage.getItem("token")== "null"){
        alert("login failed")
        
      }
      else{
        this.r.navigate(["home"])
      }
      

    }
    else{
      alert(this.logform.errors)
    }
    
   
  }

  

}
